var searchData=
[
  ['clear',['clear',['../class_n_l_1_1_smart_buffer.html#a5d67c4baf4b373290fb8b323aface006',1,'NL::SmartBuffer']]],
  ['code',['code',['../class_n_l_1_1_exception.html#aab7780ddc252c1189e5f1e52024724d6',1,'NL::Exception']]]
];
