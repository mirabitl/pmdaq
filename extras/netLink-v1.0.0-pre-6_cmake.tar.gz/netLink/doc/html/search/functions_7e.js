var searchData=
[
  ['_7esmartbuffer',['~SmartBuffer',['../class_n_l_1_1_smart_buffer.html#a4ee71a48ec838b2b5ef43a32c5de8126',1,'NL::SmartBuffer']]],
  ['_7esocket',['~Socket',['../class_n_l_1_1_socket.html#a13d111c010bad9821789fbedccc42db2',1,'NL::Socket']]]
];
