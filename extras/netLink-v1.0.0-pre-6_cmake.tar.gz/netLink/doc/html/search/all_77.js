var searchData=
[
  ['what',['what',['../class_n_l_1_1_exception.html#a4fbd95ae7fc3decc14dc52a178a9bc13',1,'NL::Exception']]]
];
