var searchData=
[
  ['nativeerrorcode',['nativeErrorCode',['../class_n_l_1_1_exception.html#a251c0feff65a97e6a5b4fae50316097a',1,'NL::Exception']]],
  ['nextreadsize',['nextReadSize',['../class_n_l_1_1_socket.html#a3cee52bb01cefc43443e62391763c81c',1,'NL::Socket']]]
];
