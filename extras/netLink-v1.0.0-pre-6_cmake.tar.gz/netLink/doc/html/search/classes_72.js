var searchData=
[
  ['releasemanager',['ReleaseManager',['../class_n_l_1_1_release_manager.html',1,'NL']]]
];
