var searchData=
[
  ['blocking',['blocking',['../class_n_l_1_1_socket.html#aba0690795e02ce0dd55993c73ca9fcc8',1,'NL::Socket::blocking() const '],['../class_n_l_1_1_socket.html#a5554f040aa8d67680e1f8e0bfaaafd21',1,'NL::Socket::blocking(bool blocking)']]],
  ['buffer',['buffer',['../class_n_l_1_1_smart_buffer.html#a2f44963531d5277b8c5995ec4d888823',1,'NL::SmartBuffer']]]
];
