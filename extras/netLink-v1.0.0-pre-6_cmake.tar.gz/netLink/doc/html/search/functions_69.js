var searchData=
[
  ['init',['init',['../namespace_n_l.html#a33d47421bd2e2106acc1a0df62bfa7ad',1,'NL']]],
  ['ipver',['ipVer',['../class_n_l_1_1_socket.html#af395d491f3d8b0eee97365dc57712336',1,'NL::Socket']]]
];
