var searchData=
[
  ['send',['send',['../class_n_l_1_1_socket.html#a253f4033321aef105d69ca37e2152b0a',1,'NL::Socket']]],
  ['sendto',['sendTo',['../class_n_l_1_1_socket.html#aae4244bbe0463915b36783681dafcd77',1,'NL::Socket']]],
  ['server',['SERVER',['../namespace_n_l.html#a6d307830453bce96847e7d79eb7e4401afb44416575dfdd51e7d33fa60c9e2e3f',1,'NL']]],
  ['setcmdonaccept',['setCmdOnAccept',['../class_n_l_1_1_socket_group.html#aaf3a37229db733bc91cad8d1b9c539fc',1,'NL::SocketGroup']]],
  ['setcmdondisconnect',['setCmdOnDisconnect',['../class_n_l_1_1_socket_group.html#a585c1437be2ed779ba54db8c645e0c9d',1,'NL::SocketGroup']]],
  ['setcmdonread',['setCmdOnRead',['../class_n_l_1_1_socket_group.html#ab547f3f9784ef297c7bdb1a556218378',1,'NL::SocketGroup']]],
  ['size',['size',['../class_n_l_1_1_smart_buffer.html#acabbd7e0ce91048b7967d09c6bdb22fb',1,'NL::SmartBuffer::size()'],['../class_n_l_1_1_socket_group.html#a98bb9e078b8c2072f507f5f661b3a3e5',1,'NL::SocketGroup::size()']]],
  ['smartbuffer',['SmartBuffer',['../class_n_l_1_1_smart_buffer.html',1,'NL']]],
  ['smartbuffer',['SmartBuffer',['../class_n_l_1_1_smart_buffer.html#ae7b059bbd714dcda7386b11c7e00ee0d',1,'NL::SmartBuffer::SmartBuffer(size_t allocSize=DEFAULT_SMARTBUFFER_SIZE, double reallocRatio=DEFAULT_SMARTBUFFER_REALLOC_RATIO)'],['../class_n_l_1_1_smart_buffer.html#a9058e1103bf628a075415390b02bffc2',1,'NL::SmartBuffer::SmartBuffer(SmartBuffer &amp;s)']]],
  ['socket',['Socket',['../class_n_l_1_1_socket.html',1,'NL']]],
  ['socket',['Socket',['../class_n_l_1_1_socket.html#a79e5e1d68be38bc2b780caa786bf6958',1,'NL::Socket::Socket(const string &amp;hostTo, unsigned portTo, Protocol protocol=TCP, IPVer ipVer=ANY)'],['../class_n_l_1_1_socket.html#a9517775895e3e488f8a8ab3ee124bb4a',1,'NL::Socket::Socket(unsigned portFrom, Protocol protocol=TCP, IPVer ipVer=IP4, const string &amp;hostFrom=&quot;&quot;, unsigned listenQueue=DEFAULT_LISTEN_QUEUE)'],['../class_n_l_1_1_socket.html#a393decfae12e78d4146d907b9b170735',1,'NL::Socket::Socket(const string &amp;hostTo, unsigned portTo, unsigned portFrom, IPVer ipVer=ANY)']]],
  ['socketgroup',['SocketGroup',['../class_n_l_1_1_socket_group.html#a23c671bf0c253701cef0986b34291fe6',1,'NL::SocketGroup']]],
  ['socketgroup',['SocketGroup',['../class_n_l_1_1_socket_group.html',1,'NL']]],
  ['socketgroupcmd',['SocketGroupCmd',['../class_n_l_1_1_socket_group_cmd.html',1,'NL']]],
  ['sockethandler',['socketHandler',['../class_n_l_1_1_socket.html#ab5d44cd3251bfad33af90883976796f6',1,'NL::Socket']]],
  ['sockettype',['SocketType',['../namespace_n_l.html#a6d307830453bce96847e7d79eb7e4401',1,'NL']]]
];
