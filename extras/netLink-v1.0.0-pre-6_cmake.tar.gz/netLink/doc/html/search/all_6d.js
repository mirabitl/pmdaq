var searchData=
[
  ['msg',['msg',['../class_n_l_1_1_exception.html#a0b7062659136993db4187508ad68a386',1,'NL::Exception']]]
];
